## fig_opt

An extension of FIG format. Options inside Fig/FigObj
comments (compatible with old mapsoft)

Options are recorded in comments in the form
"\<key>=<value>", or just "\key".

-----------
## Changelog:

2019.05.20 V.Zavjalov 1.0:
- First version

2021.01.01 V.Zavjalov 1.1:
- Change fig_get_opt interface
