This directory is for local pkg-config files.
