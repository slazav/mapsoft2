Interface to a tiled image
